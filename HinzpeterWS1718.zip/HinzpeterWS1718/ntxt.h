#ifndef NTXT_H
#define NTXT_H

enum txtzustand {nr, ein, tore};

class Cltxt {
private:
    int Spielernr=0;
    int Einsaetze=0;
    int Tore=0;
    Cltxt *naechstes;
public:
    void txtparser(ifstream& datei);
    void txtdrucker();
};

#endif // NTXT_H
