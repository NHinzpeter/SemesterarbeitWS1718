#include <iostream>
using namespace std;
#include <fstream>
#include <string.h>

#include "ntoken3.h"

ClElement *verarbeite(ifstream& datei);

int main()
{
//char dateiname[100];
ifstream eingabe;
ClToken *token;
ClElement *jetzt=NULL, *wurzel;
Cltxt *txt;

//cout << "DTD-Dateiname: " << endl;
//cin >> dateiname;
eingabe.open("datens.dtd");

wurzel=verarbeite(eingabe);
jetzt=wurzel;
cout << "Grundsaetzliche Elementstruktur:" << endl;
jetzt->druckeElement(1,wurzel);
cout << endl << endl;
eingabe.close();

// -----------------------------------

//cout << "XML-Dateiname:" << endl;
//cin >> dateiname;
eingabe.open("datens.xml");
token=new ClToken;
if (token->getToken(eingabe,NULL,wurzel)!=0) token->druckeToken(1);
eingabe.close();
cout << endl << endl;


eingabe.open("daten.txt");
txt=new Cltxt;
txt->txtparser(eingabe);
txt->txtdrucker();
eingabe.close();
}
